﻿
namespace Program3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.City = new System.Windows.Forms.Label();
            this.Item = new System.Windows.Forms.Label();
            this.Quantity = new System.Windows.Forms.Label();
            this.Ic = new System.Windows.Forms.Label();
            this.Ac = new System.Windows.Forms.Label();
            this.sc = new System.Windows.Forms.Label();
            this.tP = new System.Windows.Forms.Label();
            this.Citytxt = new System.Windows.Forms.ComboBox();
            this.ItemNumbertxt = new System.Windows.Forms.TextBox();
            this.Servingstxt = new System.Windows.Forms.TextBox();
            this.InitialCosttxt = new System.Windows.Forms.TextBox();
            this.AdjustedCosttxt = new System.Windows.Forms.TextBox();
            this.ShipmentCosttxt = new System.Windows.Forms.TextBox();
            this.TotalPricetxt = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // City
            // 
            this.City.AutoSize = true;
            this.City.Location = new System.Drawing.Point(113, 70);
            this.City.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.City.Name = "City";
            this.City.Size = new System.Drawing.Size(35, 17);
            this.City.TabIndex = 0;
            this.City.Text = "City:";
            // 
            // Item
            // 
            this.Item.AutoSize = true;
            this.Item.Location = new System.Drawing.Point(13, 102);
            this.Item.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Item.Name = "Item";
            this.Item.Size = new System.Drawing.Size(138, 17);
            this.Item.TabIndex = 1;
            this.Item.Text = "Entree/Item Number:";
            // 
            // Quantity
            // 
            this.Quantity.AutoSize = true;
            this.Quantity.Location = new System.Drawing.Point(14, 130);
            this.Quantity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Quantity.Name = "Quantity";
            this.Quantity.Size = new System.Drawing.Size(134, 17);
            this.Quantity.TabIndex = 2;
            this.Quantity.Text = "Quantity (Servings):";
            // 
            // Ic
            // 
            this.Ic.AutoSize = true;
            this.Ic.Location = new System.Drawing.Point(72, 211);
            this.Ic.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Ic.Name = "Ic";
            this.Ic.Size = new System.Drawing.Size(76, 17);
            this.Ic.TabIndex = 3;
            this.Ic.Text = "Initial Cost:";
            // 
            // Ac
            // 
            this.Ac.AutoSize = true;
            this.Ac.Location = new System.Drawing.Point(52, 238);
            this.Ac.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Ac.Name = "Ac";
            this.Ac.Size = new System.Drawing.Size(99, 17);
            this.Ac.TabIndex = 4;
            this.Ac.Text = "Adjusted Cost:";
            // 
            // sc
            // 
            this.sc.AutoSize = true;
            this.sc.Location = new System.Drawing.Point(48, 268);
            this.sc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.sc.Name = "sc";
            this.sc.Size = new System.Drawing.Size(103, 17);
            this.sc.TabIndex = 5;
            this.sc.Text = "Shipment Cost:";
            // 
            // tP
            // 
            this.tP.AutoSize = true;
            this.tP.Location = new System.Drawing.Point(68, 297);
            this.tP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tP.Name = "tP";
            this.tP.Size = new System.Drawing.Size(80, 17);
            this.tP.TabIndex = 6;
            this.tP.Text = "Total Price:";
            // 
            // Citytxt
            // 
            this.Citytxt.FormattingEnabled = true;
            this.Citytxt.Items.AddRange(new object[] {
            "Louisville",
            "Lexington",
            "Indianapolis",
            "Nashville"});
            this.Citytxt.Location = new System.Drawing.Point(156, 67);
            this.Citytxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Citytxt.Name = "Citytxt";
            this.Citytxt.Size = new System.Drawing.Size(132, 24);
            this.Citytxt.TabIndex = 7;
            // 
            // ItemNumbertxt
            // 
            this.ItemNumbertxt.Location = new System.Drawing.Point(156, 99);
            this.ItemNumbertxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ItemNumbertxt.Name = "ItemNumbertxt";
            this.ItemNumbertxt.Size = new System.Drawing.Size(132, 22);
            this.ItemNumbertxt.TabIndex = 8;
            // 
            // Servingstxt
            // 
            this.Servingstxt.Location = new System.Drawing.Point(156, 135);
            this.Servingstxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Servingstxt.Name = "Servingstxt";
            this.Servingstxt.Size = new System.Drawing.Size(132, 22);
            this.Servingstxt.TabIndex = 9;
            // 
            // InitialCosttxt
            // 
            this.InitialCosttxt.Location = new System.Drawing.Point(156, 206);
            this.InitialCosttxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.InitialCosttxt.Name = "InitialCosttxt";
            this.InitialCosttxt.Size = new System.Drawing.Size(132, 22);
            this.InitialCosttxt.TabIndex = 10;
            // 
            // AdjustedCosttxt
            // 
            this.AdjustedCosttxt.Location = new System.Drawing.Point(156, 235);
            this.AdjustedCosttxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AdjustedCosttxt.Name = "AdjustedCosttxt";
            this.AdjustedCosttxt.Size = new System.Drawing.Size(132, 22);
            this.AdjustedCosttxt.TabIndex = 11;
            // 
            // ShipmentCosttxt
            // 
            this.ShipmentCosttxt.Location = new System.Drawing.Point(156, 265);
            this.ShipmentCosttxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ShipmentCosttxt.Name = "ShipmentCosttxt";
            this.ShipmentCosttxt.Size = new System.Drawing.Size(132, 22);
            this.ShipmentCosttxt.TabIndex = 12;
            // 
            // TotalPricetxt
            // 
            this.TotalPricetxt.Location = new System.Drawing.Point(156, 294);
            this.TotalPricetxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TotalPricetxt.Name = "TotalPricetxt";
            this.TotalPricetxt.Size = new System.Drawing.Size(132, 22);
            this.TotalPricetxt.TabIndex = 13;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(116, 165);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 28);
            this.button1.TabIndex = 14;
            this.button1.Text = "Calculate";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(374, 405);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.TotalPricetxt);
            this.Controls.Add(this.ShipmentCosttxt);
            this.Controls.Add(this.AdjustedCosttxt);
            this.Controls.Add(this.InitialCosttxt);
            this.Controls.Add(this.Servingstxt);
            this.Controls.Add(this.ItemNumbertxt);
            this.Controls.Add(this.Citytxt);
            this.Controls.Add(this.tP);
            this.Controls.Add(this.sc);
            this.Controls.Add(this.Ac);
            this.Controls.Add(this.Ic);
            this.Controls.Add(this.Quantity);
            this.Controls.Add(this.Item);
            this.Controls.Add(this.City);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label City;
        private System.Windows.Forms.Label Item;
        private System.Windows.Forms.Label Quantity;
        private System.Windows.Forms.Label Ic;
        private System.Windows.Forms.Label Ac;
        private System.Windows.Forms.Label sc;
        private System.Windows.Forms.Label tP;
        private System.Windows.Forms.ComboBox Citytxt;
        private System.Windows.Forms.TextBox ItemNumbertxt;
        private System.Windows.Forms.TextBox Servingstxt;
        private System.Windows.Forms.TextBox InitialCosttxt;
        private System.Windows.Forms.TextBox AdjustedCosttxt;
        private System.Windows.Forms.TextBox ShipmentCosttxt;
        private System.Windows.Forms.TextBox TotalPricetxt;
        private System.Windows.Forms.Button button1;
    }
}

