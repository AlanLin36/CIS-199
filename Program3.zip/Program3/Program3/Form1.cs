﻿// Grading ID: S5029
// Cis 199-50
// Program 3
// Due: 11/11/2021

// This program performs calculations for meals

// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // Arrays
        const int minItemNum = 10001;
        const int maxItemNum = 10007;
        private static double[] shipmentFees = { 6.00, 7.17, 7.00, 8.74 };
        private static double[] costPerServing = { 7.87, 9.51, 10.73, 9.99, 11.99, 5.00, 4.58 };
        private static int[] servingRange = { 5, 10, 20 };
        private static int[] serviceFees = { 15, 10, 5 };

        private void button1_Click(object sender, EventArgs e)
        {
        // Variables
            int itemNumber, servings;
            double initialCost,
            serviceFee,
            adjustedCost,
            shipmentCost,
            totalCost;
        // Make sure if the wrong inputs are given it gives a error message
            if (Citytxt.SelectedIndex == -1)
            {
                MessageBox.Show("Select a City");
            }
            else if (int.TryParse(ItemNumbertxt.Text, out itemNumber) == false || itemNumber < minItemNum || itemNumber > maxItemNum)
            {
                MessageBox.Show("Invalid Item Number");
            }
            else if (int.TryParse(Servingstxt.Text, out servings) == false || servings < 0)
            {
                MessageBox.Show("Invalid Servings");
            }
            else
            {
                initialCost = costPerServing[itemNumber % minItemNum] * servings;
                serviceFee = 0;
                if (servings >= 21)
                {
                    serviceFee = 0;
                }
                else
                {
                    for (int index = 0; index < servingRange.Length; index++)
                    {
                        if (servings <= servingRange[index])
                        {
                            serviceFee = initialCost * serviceFees[index] / 100;
                        }
                    }
                }

                // Formulas
                adjustedCost = initialCost + serviceFee;
                shipmentCost = adjustedCost * shipmentFees[Citytxt.SelectedIndex] / 100;
                totalCost = adjustedCost + shipmentCost;
                // Display 
                InitialCosttxt.Text = $"{initialCost:C2}";
                AdjustedCosttxt.Text = $"{adjustedCost:C2}";
                ShipmentCosttxt.Text = $"{shipmentCost:C2}";
                TotalPricetxt.Text = $"{totalCost:C2}";

            }

        }

    }

}
