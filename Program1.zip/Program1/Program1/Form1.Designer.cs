﻿
namespace Program1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.width = new System.Windows.Forms.Label();
            this.widthtxt = new System.Windows.Forms.TextBox();
            this.lengthtxt = new System.Windows.Forms.TextBox();
            this.length = new System.Windows.Forms.Label();
            this.depthtxt = new System.Windows.Forms.TextBox();
            this.depth = new System.Windows.Forms.Label();
            this.materialtxt = new System.Windows.Forms.TextBox();
            this.material = new System.Windows.Forms.Label();
            this.exctxt = new System.Windows.Forms.TextBox();
            this.excavation = new System.Windows.Forms.Label();
            this.dbtxt = new System.Windows.Forms.TextBox();
            this.diveboard = new System.Windows.Forms.Label();
            this.cytxt = new System.Windows.Forms.TextBox();
            this.cubicy = new System.Windows.Forms.Label();
            this.mctxt = new System.Windows.Forms.TextBox();
            this.materialc = new System.Windows.Forms.Label();
            this.ectxt = new System.Windows.Forms.TextBox();
            this.excavationc = new System.Windows.Forms.Label();
            this.lctxt = new System.Windows.Forms.TextBox();
            this.laborc = new System.Windows.Forms.Label();
            this.tctxt = new System.Windows.Forms.TextBox();
            this.totalc = new System.Windows.Forms.Label();
            this.calculate = new System.Windows.Forms.Button();
            this.Title = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // width
            // 
            this.width.AutoSize = true;
            this.width.Location = new System.Drawing.Point(44, 39);
            this.width.Name = "width";
            this.width.Size = new System.Drawing.Size(112, 13);
            this.width.TabIndex = 0;
            this.width.Text = "Max Width of Pool (ft):";
            // 
            // widthtxt
            // 
            this.widthtxt.Location = new System.Drawing.Point(162, 36);
            this.widthtxt.Name = "widthtxt";
            this.widthtxt.Size = new System.Drawing.Size(100, 20);
            this.widthtxt.TabIndex = 1;
            // 
            // lengthtxt
            // 
            this.lengthtxt.Location = new System.Drawing.Point(162, 62);
            this.lengthtxt.Name = "lengthtxt";
            this.lengthtxt.Size = new System.Drawing.Size(100, 20);
            this.lengthtxt.TabIndex = 3;
            // 
            // length
            // 
            this.length.AutoSize = true;
            this.length.Location = new System.Drawing.Point(39, 65);
            this.length.Name = "length";
            this.length.Size = new System.Drawing.Size(117, 13);
            this.length.TabIndex = 2;
            this.length.Text = "Max Length of Pool (ft):";
            // 
            // depthtxt
            // 
            this.depthtxt.Location = new System.Drawing.Point(162, 88);
            this.depthtxt.Name = "depthtxt";
            this.depthtxt.Size = new System.Drawing.Size(100, 20);
            this.depthtxt.TabIndex = 5;
            // 
            // depth
            // 
            this.depth.AutoSize = true;
            this.depth.Location = new System.Drawing.Point(46, 91);
            this.depth.Name = "depth";
            this.depth.Size = new System.Drawing.Size(113, 13);
            this.depth.TabIndex = 4;
            this.depth.Text = "Max Depth of Pool (ft):";
            // 
            // materialtxt
            // 
            this.materialtxt.Location = new System.Drawing.Point(162, 114);
            this.materialtxt.Name = "materialtxt";
            this.materialtxt.Size = new System.Drawing.Size(100, 20);
            this.materialtxt.TabIndex = 7;
            // 
            // material
            // 
            this.material.AutoSize = true;
            this.material.Location = new System.Drawing.Point(28, 117);
            this.material.Name = "material";
            this.material.Size = new System.Drawing.Size(128, 13);
            this.material.TabIndex = 6;
            this.material.Text = "Materials Price (cubic yd):";
            // 
            // exctxt
            // 
            this.exctxt.Location = new System.Drawing.Point(162, 140);
            this.exctxt.Name = "exctxt";
            this.exctxt.Size = new System.Drawing.Size(100, 20);
            this.exctxt.TabIndex = 9;
            // 
            // excavation
            // 
            this.excavation.AutoSize = true;
            this.excavation.Location = new System.Drawing.Point(46, 140);
            this.excavation.Name = "excavation";
            this.excavation.Size = new System.Drawing.Size(110, 26);
            this.excavation.TabIndex = 8;
            this.excavation.Text = "Excavation Needed?:\r\n(1 = YES, 0 = NO)";
            this.excavation.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // dbtxt
            // 
            this.dbtxt.Location = new System.Drawing.Point(162, 178);
            this.dbtxt.Name = "dbtxt";
            this.dbtxt.Size = new System.Drawing.Size(100, 20);
            this.dbtxt.TabIndex = 11;
            // 
            // diveboard
            // 
            this.diveboard.AutoSize = true;
            this.diveboard.Location = new System.Drawing.Point(64, 172);
            this.diveboard.Name = "diveboard";
            this.diveboard.Size = new System.Drawing.Size(92, 26);
            this.diveboard.TabIndex = 10;
            this.diveboard.Text = "Diving Board?:\r\n(1 = YES, 0 = NO)";
            this.diveboard.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // cytxt
            // 
            this.cytxt.Location = new System.Drawing.Point(162, 232);
            this.cytxt.Name = "cytxt";
            this.cytxt.Size = new System.Drawing.Size(100, 20);
            this.cytxt.TabIndex = 13;
            // 
            // cubicy
            // 
            this.cubicy.AutoSize = true;
            this.cubicy.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.cubicy.Location = new System.Drawing.Point(89, 235);
            this.cubicy.Name = "cubicy";
            this.cubicy.Size = new System.Drawing.Size(67, 13);
            this.cubicy.TabIndex = 12;
            this.cubicy.Text = "Cubic Yards:";
            // 
            // mctxt
            // 
            this.mctxt.Location = new System.Drawing.Point(162, 258);
            this.mctxt.Name = "mctxt";
            this.mctxt.Size = new System.Drawing.Size(100, 20);
            this.mctxt.TabIndex = 15;
            // 
            // materialc
            // 
            this.materialc.AutoSize = true;
            this.materialc.Location = new System.Drawing.Point(80, 261);
            this.materialc.Name = "materialc";
            this.materialc.Size = new System.Drawing.Size(76, 13);
            this.materialc.TabIndex = 14;
            this.materialc.Text = "Materials Cost:";
            // 
            // ectxt
            // 
            this.ectxt.Location = new System.Drawing.Point(162, 284);
            this.ectxt.Name = "ectxt";
            this.ectxt.Size = new System.Drawing.Size(100, 20);
            this.ectxt.TabIndex = 17;
            // 
            // excavationc
            // 
            this.excavationc.AutoSize = true;
            this.excavationc.Location = new System.Drawing.Point(69, 287);
            this.excavationc.Name = "excavationc";
            this.excavationc.Size = new System.Drawing.Size(87, 13);
            this.excavationc.TabIndex = 16;
            this.excavationc.Text = "Excavation Cost:";
            // 
            // lctxt
            // 
            this.lctxt.Location = new System.Drawing.Point(162, 310);
            this.lctxt.Name = "lctxt";
            this.lctxt.Size = new System.Drawing.Size(100, 20);
            this.lctxt.TabIndex = 19;
            // 
            // laborc
            // 
            this.laborc.AutoSize = true;
            this.laborc.Location = new System.Drawing.Point(95, 313);
            this.laborc.Name = "laborc";
            this.laborc.Size = new System.Drawing.Size(61, 13);
            this.laborc.TabIndex = 18;
            this.laborc.Text = "Labor Cost:";
            // 
            // tctxt
            // 
            this.tctxt.Location = new System.Drawing.Point(162, 339);
            this.tctxt.Name = "tctxt";
            this.tctxt.Size = new System.Drawing.Size(100, 20);
            this.tctxt.TabIndex = 21;
            // 
            // totalc
            // 
            this.totalc.AutoSize = true;
            this.totalc.Location = new System.Drawing.Point(98, 342);
            this.totalc.Name = "totalc";
            this.totalc.Size = new System.Drawing.Size(58, 13);
            this.totalc.TabIndex = 20;
            this.totalc.Text = "Total Cost:";
            // 
            // calculate
            // 
            this.calculate.Location = new System.Drawing.Point(105, 380);
            this.calculate.Name = "calculate";
            this.calculate.Size = new System.Drawing.Size(106, 23);
            this.calculate.TabIndex = 22;
            this.calculate.Text = "Calculate Estimate";
            this.calculate.UseVisualStyleBackColor = true;
            this.calculate.Click += new System.EventHandler(this.calculate_Click);
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Location = new System.Drawing.Point(104, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(120, 13);
            this.Title.TabIndex = 23;
            this.Title.Text = "EZ-Pools Cost Estimator";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(317, 450);
            this.Controls.Add(this.Title);
            this.Controls.Add(this.calculate);
            this.Controls.Add(this.tctxt);
            this.Controls.Add(this.totalc);
            this.Controls.Add(this.lctxt);
            this.Controls.Add(this.laborc);
            this.Controls.Add(this.ectxt);
            this.Controls.Add(this.excavationc);
            this.Controls.Add(this.mctxt);
            this.Controls.Add(this.materialc);
            this.Controls.Add(this.cytxt);
            this.Controls.Add(this.cubicy);
            this.Controls.Add(this.dbtxt);
            this.Controls.Add(this.diveboard);
            this.Controls.Add(this.exctxt);
            this.Controls.Add(this.excavation);
            this.Controls.Add(this.materialtxt);
            this.Controls.Add(this.material);
            this.Controls.Add(this.depthtxt);
            this.Controls.Add(this.depth);
            this.Controls.Add(this.lengthtxt);
            this.Controls.Add(this.length);
            this.Controls.Add(this.widthtxt);
            this.Controls.Add(this.width);
            this.Name = "Form1";
            this.Text = "Program 1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label width;
        private System.Windows.Forms.TextBox widthtxt;
        private System.Windows.Forms.TextBox lengthtxt;
        private System.Windows.Forms.Label length;
        private System.Windows.Forms.TextBox depthtxt;
        private System.Windows.Forms.Label depth;
        private System.Windows.Forms.TextBox materialtxt;
        private System.Windows.Forms.Label material;
        private System.Windows.Forms.TextBox exctxt;
        private System.Windows.Forms.Label excavation;
        private System.Windows.Forms.TextBox dbtxt;
        private System.Windows.Forms.Label diveboard;
        private System.Windows.Forms.TextBox cytxt;
        private System.Windows.Forms.Label cubicy;
        private System.Windows.Forms.TextBox mctxt;
        private System.Windows.Forms.Label materialc;
        private System.Windows.Forms.TextBox ectxt;
        private System.Windows.Forms.Label excavationc;
        private System.Windows.Forms.TextBox lctxt;
        private System.Windows.Forms.Label laborc;
        private System.Windows.Forms.TextBox tctxt;
        private System.Windows.Forms.Label totalc;
        private System.Windows.Forms.Button calculate;
        private System.Windows.Forms.Label Title;
    }
}

