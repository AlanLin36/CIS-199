﻿// Grading ID: S5029
// Cis 199-50
// Program 1
// Due: 9/30/2021

// This program performs calculation of the
// cost for a pool

// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculate_Click(object sender, EventArgs e)
        {
            // Variables
            double cubicy,
                materialc,
                excavationc,
                laborc,
                totalc,
                width,
                length,
                depth,
                material;

            // Text
            width = double.Parse(widthtxt.Text);
            length = double.Parse(lengthtxt.Text);
            depth = double.Parse(depthtxt.Text);
            material = double.Parse(materialtxt.Text);

            // Constants
            const double eec = 15;
            const double fl = 50;
            const double laborcharge = 3.25;
            const double excess = .1;
            const double conversion = 27;

            excavationc = 0;
            laborc = 0;

            // Calculates the area
            cubicy = width * length * depth / conversion;

            int excavation = int.Parse(exctxt.Text);
            int db = int.Parse(dbtxt.Text);

            if (excavation == 1) 
            { excavationc = eec * cubicy; }
            if (db == 1) 
            { laborc = fl; }

            // Formula
            materialc = material * cubicy;
            materialc = materialc * excess + materialc;
            laborc = laborcharge * cubicy + laborc;
            totalc = laborc + excavationc + materialc;

            // Display the calculations
                cytxt.Text = $"{cubicy:F1}";
                mctxt.Text = $"{materialc:C2}";
                ectxt.Text = $"{excavationc:C2}";
                lctxt.Text = $"{laborc:C2}";
                tctxt.Text = $"{totalc:C2}";
            }
    }
}
