﻿// Grading ID: S5029
// Cis 199-50
// Program 2
// Due: 10/21/2021

// This program performs calculations to see 
// the lowest cost for between 3 companies

// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Variables
            double TotalA,
                TotalB,
                TotalC,
                Mile;

            int Passenger;

            // Company A Constants
            const double aPerMile = 0.02;
            const double aPerPassenger = 2;
            const double aIndex0 = 50;
            const double aIndex1 = 40;
            const double aIndex2 = 25;
            const double aIndex3 = 15;
            const double aIndex4 = 7;
            double CarTypeFeeA = 0,
                PassengerFeeA,
                DistanceFeeA;

            // Company B Constants
            const double bPerPassenger1 = 20;
            const double bPerPassenger2 = 15;
            const double bPerPassenger3 = 5;
            const double bPerMile = .10;
            const double bIndex01 = 40;
            const double bIndex2 = 25;
            const double bIndex34 = 15;
            double CarTypeFeeB = 0,
                PassengerFeeB,
                DistanceFeeB,
                bPerPassenger = 0;

            // Company C Constants
            const double cPerPassenger = .25;
            const double cPerMile1 = 40;
            const double cPerMile2 = 35;
            const double cPerMile3 = 25;
            const double cPerMile4 = 15;
            const double cPerMile5 = 5;
            const double cIndex = 20;
            double CarTypeFeeC,
                PassengerFeeC,
                DistanceFeeC;
            double cPerMile = 0;

            // Distance
            if (double.TryParse(Distancetxt.Text, out Mile) && (Mile < 0))
            { MessageBox.Show("Invalid Distance"); }
            if (double.TryParse(Distancetxt.Text, out Mile) && (Mile >= 200))
            { cPerMile = cPerMile1; }
            if (Mile >= 100 && Mile <= 199)
            { cPerMile = cPerMile2; }
            if (Mile >= 50 && Mile <= 99)
            { cPerMile = cPerMile3; }
            if (Mile >= 10 && Mile <= 49)
            { cPerMile = cPerMile4; }
            if (Mile >= 0 && Mile <= 9)
            { cPerMile = cPerMile5; }

            // Passenger
            if (int.TryParse(Passengerstxt.Text, out Passenger) && (Passenger <= 12  && Passenger >= 1))
            { Passengerstxt.Text = $"{Passenger:F0}"; }
            else
            { MessageBox.Show("Invalid Number of Passenger"); }

            if (int.TryParse(Passengerstxt.Text, out Passenger) && (Passenger >= 0 && Passenger <=2))
            { bPerPassenger = bPerPassenger1; }
            if ( Passenger >= 3 && Passenger <= 6)
            { bPerPassenger = bPerPassenger2; }
            if (Passenger >= 7 && Passenger <= 12)
            { bPerPassenger = bPerPassenger3; }

            // Car Type
            if (carTypeTxt.SelectedIndex == 0)
            {
                CarTypeFeeA = aIndex0;
                CarTypeFeeB = bIndex01;
            }
            if (carTypeTxt.SelectedIndex == 1)
            {
                CarTypeFeeA = aIndex1;
                CarTypeFeeB = bIndex01;
            }
            if (carTypeTxt.SelectedIndex == 2)
            {
                CarTypeFeeA = aIndex2;
                CarTypeFeeB = bIndex2;
            }
            if (carTypeTxt.SelectedIndex == 3)
            {
                CarTypeFeeA = aIndex3;
                CarTypeFeeB = bIndex34;
            }
            if (carTypeTxt.SelectedIndex == 4)
            {
                CarTypeFeeA = aIndex4;
                CarTypeFeeB = bIndex34;
            }

            // Text
            Mile = double.Parse(Distancetxt.Text);
            Passenger = int.Parse(Passengerstxt.Text);

            // Company A Calculation
            PassengerFeeA = aPerPassenger * Passenger;
            DistanceFeeA = aPerMile * Mile;
            TotalA = CarTypeFeeA + PassengerFeeA + DistanceFeeA;

            // Company B Calculation
            PassengerFeeB = bPerPassenger * Passenger;
            DistanceFeeB = bPerMile * Mile;
            TotalB = CarTypeFeeB + PassengerFeeB + DistanceFeeB;

            // Company C Calculation
            DistanceFeeC = cPerMile;
            PassengerFeeC = cPerPassenger * Passenger;
            CarTypeFeeC = cIndex;
            TotalC = CarTypeFeeC + PassengerFeeC + DistanceFeeC;


            // Display
            CompanyAtxt.Text = $"{TotalA:C2}";
            CompanyBtxt.Text = $"{TotalB:C2}";
            CompanyCtxt.Text = $"{TotalC:C2}";

            // Results
            if (TotalA < TotalB && TotalA < TotalC)
            { 
              resultsTxt.Text = "The lowest cost company is: A";
            }
            if (TotalB < TotalA && TotalB < TotalC)
            { 
                resultsTxt.Text = "The lowest cost company is: B";
            }
            if (TotalC < TotalA && TotalC < TotalB)
            { 
              resultsTxt.Text = "The lowest cost company is: C";
            }
        }
    }
}
