﻿
namespace Program2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.p = new System.Windows.Forms.Label();
            this.d = new System.Windows.Forms.Label();
            this.cT = new System.Windows.Forms.Label();
            this.cal = new System.Windows.Forms.Button();
            this.Passengerstxt = new System.Windows.Forms.TextBox();
            this.Distancetxt = new System.Windows.Forms.TextBox();
            this.CompanyAtxt = new System.Windows.Forms.TextBox();
            this.CompanyBtxt = new System.Windows.Forms.TextBox();
            this.CompanyCtxt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cA = new System.Windows.Forms.Label();
            this.cB = new System.Windows.Forms.Label();
            this.cC = new System.Windows.Forms.Label();
            this.resultsTxt = new System.Windows.Forms.TextBox();
            this.carTypeTxt = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // p
            // 
            this.p.AutoSize = true;
            this.p.Location = new System.Drawing.Point(32, 69);
            this.p.Name = "p";
            this.p.Size = new System.Drawing.Size(92, 13);
            this.p.TabIndex = 0;
            this.p.Text = "Passengers (1-12)";
            // 
            // d
            // 
            this.d.AutoSize = true;
            this.d.Location = new System.Drawing.Point(45, 126);
            this.d.Name = "d";
            this.d.Size = new System.Drawing.Size(82, 13);
            this.d.TabIndex = 1;
            this.d.Text = "Distance (Miles)";
            // 
            // cT
            // 
            this.cT.AutoSize = true;
            this.cT.Location = new System.Drawing.Point(74, 175);
            this.cT.Name = "cT";
            this.cT.Size = new System.Drawing.Size(53, 13);
            this.cT.TabIndex = 2;
            this.cT.Text = "Car Type:";
            // 
            // cal
            // 
            this.cal.Location = new System.Drawing.Point(76, 258);
            this.cal.Name = "cal";
            this.cal.Size = new System.Drawing.Size(91, 23);
            this.cal.TabIndex = 3;
            this.cal.Text = "Calculate Cost";
            this.cal.UseVisualStyleBackColor = true;
            this.cal.Click += new System.EventHandler(this.button1_Click);
            // 
            // Passengerstxt
            // 
            this.Passengerstxt.Location = new System.Drawing.Point(139, 67);
            this.Passengerstxt.Name = "Passengerstxt";
            this.Passengerstxt.Size = new System.Drawing.Size(86, 20);
            this.Passengerstxt.TabIndex = 4;
            // 
            // Distancetxt
            // 
            this.Distancetxt.Location = new System.Drawing.Point(139, 124);
            this.Distancetxt.Name = "Distancetxt";
            this.Distancetxt.Size = new System.Drawing.Size(86, 20);
            this.Distancetxt.TabIndex = 5;
            // 
            // CompanyAtxt
            // 
            this.CompanyAtxt.BackColor = System.Drawing.SystemColors.Menu;
            this.CompanyAtxt.Location = new System.Drawing.Point(411, 57);
            this.CompanyAtxt.Name = "CompanyAtxt";
            this.CompanyAtxt.Size = new System.Drawing.Size(84, 20);
            this.CompanyAtxt.TabIndex = 6;
            this.CompanyAtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // CompanyBtxt
            // 
            this.CompanyBtxt.BackColor = System.Drawing.SystemColors.Menu;
            this.CompanyBtxt.Location = new System.Drawing.Point(411, 114);
            this.CompanyBtxt.Name = "CompanyBtxt";
            this.CompanyBtxt.Size = new System.Drawing.Size(84, 20);
            this.CompanyBtxt.TabIndex = 7;
            this.CompanyBtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // CompanyCtxt
            // 
            this.CompanyCtxt.BackColor = System.Drawing.SystemColors.Menu;
            this.CompanyCtxt.Location = new System.Drawing.Point(411, 168);
            this.CompanyCtxt.Name = "CompanyCtxt";
            this.CompanyCtxt.Size = new System.Drawing.Size(84, 20);
            this.CompanyCtxt.TabIndex = 8;
            this.CompanyCtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(267, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Results";
            // 
            // cA
            // 
            this.cA.AutoSize = true;
            this.cA.Location = new System.Drawing.Point(298, 57);
            this.cA.Name = "cA";
            this.cA.Size = new System.Drawing.Size(85, 13);
            this.cA.TabIndex = 10;
            this.cA.Text = "Company A Cost";
            // 
            // cB
            // 
            this.cB.AutoSize = true;
            this.cB.Location = new System.Drawing.Point(298, 114);
            this.cB.Name = "cB";
            this.cB.Size = new System.Drawing.Size(85, 13);
            this.cB.TabIndex = 11;
            this.cB.Text = "Company B Cost";
            // 
            // cC
            // 
            this.cC.AutoSize = true;
            this.cC.Location = new System.Drawing.Point(298, 168);
            this.cC.Name = "cC";
            this.cC.Size = new System.Drawing.Size(85, 13);
            this.cC.TabIndex = 12;
            this.cC.Text = "Company C Cost";
            // 
            // resultsTxt
            // 
            this.resultsTxt.BackColor = System.Drawing.SystemColors.Menu;
            this.resultsTxt.Location = new System.Drawing.Point(301, 220);
            this.resultsTxt.Name = "resultsTxt";
            this.resultsTxt.Size = new System.Drawing.Size(210, 20);
            this.resultsTxt.TabIndex = 13;
            this.resultsTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // carTypeTxt
            // 
            this.carTypeTxt.FormattingEnabled = true;
            this.carTypeTxt.Items.AddRange(new object[] {
            "Limbo",
            "Luxury",
            "Mid-Tier",
            "Green",
            "Economy"});
            this.carTypeTxt.Location = new System.Drawing.Point(139, 172);
            this.carTypeTxt.Name = "carTypeTxt";
            this.carTypeTxt.Size = new System.Drawing.Size(86, 21);
            this.carTypeTxt.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 330);
            this.Controls.Add(this.carTypeTxt);
            this.Controls.Add(this.resultsTxt);
            this.Controls.Add(this.cC);
            this.Controls.Add(this.cB);
            this.Controls.Add(this.cA);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.CompanyCtxt);
            this.Controls.Add(this.CompanyBtxt);
            this.Controls.Add(this.CompanyAtxt);
            this.Controls.Add(this.Distancetxt);
            this.Controls.Add(this.Passengerstxt);
            this.Controls.Add(this.cal);
            this.Controls.Add(this.cT);
            this.Controls.Add(this.d);
            this.Controls.Add(this.p);
            this.Name = "Form1";
            this.Text = "Program 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label p;
        private System.Windows.Forms.Label d;
        private System.Windows.Forms.Label cT;
        private System.Windows.Forms.Button cal;
        private System.Windows.Forms.TextBox Passengerstxt;
        private System.Windows.Forms.TextBox Distancetxt;
        private System.Windows.Forms.TextBox CompanyAtxt;
        private System.Windows.Forms.TextBox CompanyBtxt;
        private System.Windows.Forms.TextBox CompanyCtxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label cA;
        private System.Windows.Forms.Label cB;
        private System.Windows.Forms.Label cC;
        private System.Windows.Forms.TextBox resultsTxt;
        private System.Windows.Forms.ComboBox carTypeTxt;
    }
}

