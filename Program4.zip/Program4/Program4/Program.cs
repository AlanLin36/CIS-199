﻿// Grading ID: S5029
// Cis 199-50
// Program 4
// Due: 12/4/2021

// This program display which books are checkout out and whats avaliable
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Program4
{
    public class LibraryBook
    {
        // variables
        private String bookTitle;
        private String bookAuthor;
        private String bookPublisher;
        private int bookYearOfPublication;
        private String bookISBN;
        private bool checkoutStatus;

        // Constructor for LibraryBook
        public LibraryBook(String theTitle, String theAuthor, String thePublisher, int theYearOfPublication, String theISBN)
        {
            bookTitle = theTitle;
            bookAuthor = theAuthor;
            bookPublisher = thePublisher;
            bookYearOfPublication = theYearOfPublication;
            bookISBN = theISBN;
            checkoutStatus = false;
        }
        // properties with get and set
        public String BookTitle
        {
            get {return bookTitle;}
            set {bookTitle = value;}
        }
        public String BookAuthor
        {
            get {return bookAuthor;}
            set {bookAuthor = value;}
        }
        public String BookPublisher
        {
            get {return bookPublisher;}
            set {bookPublisher = value;}
        }
        public int YearOfPublication
        {
            get {return bookYearOfPublication;}
            set {bookYearOfPublication = value;}
        }
        public String ISBN
        {
            get {return bookISBN;}
            set {bookISBN = value;}
        }
        // Status of Books
        public void CheckOut()
        { checkoutStatus = !checkoutStatus; }
        public void ReturnToShelf()
        { checkoutStatus = !checkoutStatus; }
        public bool IsCheckedOut()
        { return checkoutStatus; }

        // ToString Method
        public override String ToString()
        {
            return $"Title: {bookTitle}{Environment.NewLine}" + $"Author: {bookAuthor}{Environment.NewLine}" + $"Publisher: {bookPublisher}{Environment.NewLine}" + $"Year of Publication: {bookYearOfPublication}{Environment.NewLine}" + $"ISBN: {bookISBN}{Environment.NewLine}" + $"Checkout Status: {checkoutStatus}{Environment.NewLine}";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // 5 Library Books object
            LibraryBook book1 = new LibraryBook("Book 1", "Author 1", "Publisher 1", 2000, "01");
            LibraryBook book2 = new LibraryBook("Book 2", "Author 2", "Publisher 2", 2001, "02");
            LibraryBook book3 = new LibraryBook("Book 3", "Author 3", "Publisher 3", 2002, "03");
            LibraryBook book4 = new LibraryBook("Book 4", "Author 4", "Publisher 4", 2003, "04");
            LibraryBook book5 = new LibraryBook("Book 5", "Author 5", "Publisher 5", 2004, "05");

            
            LibraryBook[] books = { book1, book2, book3, book4, book5 };

            // Display Orgiginal data
            WriteLine("Original Data\n");
            printBooks(books);

            book1.CheckOut();
            book2.BookAuthor = "Author 2";
            book3.ISBN = "03";
            book4.CheckOut();
            book5.CheckOut();

            // Display checkout books
            WriteLine("Checked Out Books\n");
            printBooks(books);

            book1.CheckOut();
            book2.CheckOut();
            book3.CheckOut();
            book4.CheckOut();
            book5.CheckOut();

            // Display updated data
            WriteLine("New Data\n");
            printBooks(books);
        }

        // Display Library Books
        static void printBooks(LibraryBook[] books)
        {
            for (int i = 0; i < books.Length; i++)
            {
                WriteLine("Book #" + (i + 1));
                WriteLine(books[i]);
            }
        }
    }
}
